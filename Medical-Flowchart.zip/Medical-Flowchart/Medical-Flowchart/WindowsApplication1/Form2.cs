using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsApplication1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        int case_id=0;
        private void button1_Click(object sender, EventArgs e)
        {
                    case_id=0;

                    richTextBox1.Text = "does the patient have a typical or  atypical anginal pain?";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            handle_it(true);
        }

        void handle_it(bool stat)
        {
            switch (case_id)
            {
                case 0:
                    if (stat)
                    {
                        case_id = 1;
                        richTextBox1.Text = "Is the ECG normal or near normal ?";
                    }
                    else
                    {
                        case_id = -1;
                        richTextBox1.Text = "Is there suspection for embolism?";
                    }
                    break;




                case 1:
                    if (stat)
                    {
                        case_id = 3;
                        richTextBox1.Text = "measure traponin levels;;;\nAre traponin levels normal ?";
                    }
                    else
                    {
                        case_id = 2;
                        richTextBox1.Text = "Evaluate as an inpatient !!";
                    }
                    break;




                case -1:
                    if (stat)
                    {
                        case_id = -3;
                        richTextBox1.Text = "Calculate Wells scores;;;\n Wells scores less than 2?";
                    }
                    else
                    {
                        case_id = -2;
                        richTextBox1.Text = "does the patient have fever; egophony?";
                    }
                    break;



                case 2:

                    richTextBox1.Text = "Evaluate as an inpatient !!";
                    break;






                case 3:
                    if (stat)
                    {
                        case_id = 4;
                        richTextBox1.Text = "with low risk --> perform stress ECG\nwith moderate risk --> perform stress ECG with scan\nwith high risk --> perform angiography";
                    }
                    else
                    {
                        case_id = 2;
                        richTextBox1.Text = "Evaluate as an inpatient !!";
                    }
                    break;




                case -2:
                    if (stat)
                    {
                        case_id = 6;
                        richTextBox1.Text = "perform chest radiography";
                    }
                    else
                    {
                        case_id = 5;
                        richTextBox1.Text = "has the patient had fright; anxiety?";
                    }
                    break;



                case 6:

                    richTextBox1.Text = "perform chest radiography";
                    break;


                case 5:
                    if (stat)
                    {
                        case_id = 8;
                        richTextBox1.Text = "Panic disorder";
                    }
                    else
                    {
                        case_id = 7;
                        richTextBox1.Text = "Is the pain by palpation?";
                    }
                    break;


                case 8:

                    richTextBox1.Text = "Panic disorder";
                    break;

                case 4:

                    richTextBox1.Text = "with low risk --> perform stress ECG\nwith moderate risk --> perform stress ECG with scan\nwith high risk --> perform angiography";
                    break;


                case 7:
                    if (stat)
                    {
                        case_id = 10;
                        richTextBox1.Text = "chest wall pain";
                    }
                    else
                    {
                        case_id = 9;
                        richTextBox1.Text = "heart failure\r\n cure is to use chock";
                    }
                    break;


                case 10:

                    richTextBox1.Text = "chest wall pain";
                    break;


                case 9:

                    richTextBox1.Text = "heart failure\r\n cure is to use chock";
                    break;



                case -3:
                    if (stat)
                    {
                        case_id = -5;
                        richTextBox1.Text = "Measure D-dimee;;;\n Is the D-dimee normal?";
                    }
                    else
                    {
                        case_id = -4;
                        richTextBox1.Text = "Perform CT and venous ultrasound;;;\n CT scan positive?";
                    }
                    break;


                case -5:
                    if (stat)
                    {
                        case_id = -6;
                        richTextBox1.Text = "no further testing !!";
                    }
                    else
                    {
                        case_id = -4;
                        richTextBox1.Text = "Perform CT and venous ultrasound;;;\n CT scan positive?";
                    }
                    break;



                case -6:

                    richTextBox1.Text = "no further testing !!";
                    break;


                case -7:

                    richTextBox1.Text = "Treat for pulmonary embolism";
                    break;

                case -9:

                    richTextBox1.Text = "Treat for deep venous thrombosis";
                    break;



                case -12:

                    richTextBox1.Text = "perform pulmonary angiography";
                    break;

                case -11:

                    richTextBox1.Text = "perform serial ultrasound";
                    break;



                case -4:
                    if (stat)
                    {
                        case_id = -7;
                        richTextBox1.Text = "Treat for pulmonary embolism";
                    }
                    else
                    {
                        case_id = -8;
                        richTextBox1.Text = "Perform CT and venous ultrasound;;;\n venous ultrasound results positive?";
                    }
                    break;



                case -8:
                    if (stat)
                    {
                        case_id = -9;
                        richTextBox1.Text = "Treat for deep venous thrombosis";
                    }
                    else
                    {
                        case_id = -10;
                        richTextBox1.Text = "CT and venous ultrasound normal;;;\n Walls scoe > 6 ?";
                    }
                    break;






                case -10:
                    if (stat)
                    {
                        case_id = -12;
                        richTextBox1.Text = "perform pulmonary angiography";
                    }
                    else
                    {
                        case_id = -11;
                        richTextBox1.Text = "perform serial ultrasound";
                    }
                    break;



                default:
                    richTextBox1.Text = "sorry";
                    break;


   }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            handle_it(false);
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            case_id = 0;

            richTextBox1.Text = "does the patient have a typical or  atypical anginal pain?";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            new Form3().Show();
        }
       
    }
}